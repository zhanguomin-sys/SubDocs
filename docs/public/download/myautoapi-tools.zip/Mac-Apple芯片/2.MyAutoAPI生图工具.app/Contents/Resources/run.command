#!/bin/bash
set -u
resource_dir="$(cd "$(dirname "$0")" && pwd)"
"$resource_dir/tool" install
result=$?
printf '\n按回车结束，随后可关闭本窗口。'
IFS= read -r ignored </dev/tty || true
exit "$result"
